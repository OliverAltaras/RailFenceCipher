package ie.gmit.dip;

/* This class has the main method. It invokes the go() method from the Menu
class, which kick starts the application*/
public class Runner {

	public static void main(String[] args) {

		new Menu().go();

	}
}
