package ie.gmit.dip;

import java.io.IOException;
import java.util.Scanner;

public class Menu {
	InputOutputHandler ioh = new InputOutputHandler();
	private Scanner scan = new Scanner(System.in);
	private boolean keepRunning = true;

	/*
	 * This method sits at the top of the tree. When it is invoked in the Runner
	 * class, the application starts
	 */
	public void go() {
		menuLayout();
		while (keepRunning) {
			choices();
		}

	}

	/*
	 * This methods allows the user to input an option from 1-4 or the word "Menu",
	 * which brings them back to the homescreen. Options 1-3 invoke the parse
	 * method, from the InputOutputHandler class. Depending on the argument
	 * provided, it will then call a different method from the RailFenceCypher class
	 */
	public void choices() {

		String menuChoice = scan.nextLine();

		if (menuChoice.equals("1"))
			menuMethods(1);
		else if (menuChoice.equals("2"))
			menuMethods(2);
		else if (menuChoice.equals("3"))
			menuMethods(3);
		else if (menuChoice.equals("4")) {
			keepRunning = false;
			System.out.println("Bye-bye! =(");
		} else if (menuChoice.equals("menu") || menuChoice.equals("Menu"))
			go();
		else {
			System.out.println("Invalid option! You must choose between 1 and 4 or enter 'Menu'>");
			choices();
		}

	}

	// This method displays the menu layout
	private void menuLayout() {
		System.out.println("*****************************************");
		System.out.println("  Welcome to Rail Fence Cypher 00387943  ");
		System.out.println("*****************************************");
		System.out.println("");
		System.out.println("1 - Encrypt a file or URL> ");
		System.out.println("2 - Decrypt a file or URL> ");
		System.out.println("3 - Display the rail fence> ");
		System.out.println("4 - Quit> ");
		System.out.println("");
		System.out.println("Type option [1-4]>");
	}

	/*
	 * This method simplifies the choices() method above. It handles every IO
	 * exception and makes it easier to invoke different methods on the menu. All it
	 * requires is an integer as an argument, which will be the same number as the
	 * option on the menu. For instance, argument (int 1) invokes the encrypt
	 * method, which is also option 1 on the menu
	 */
	public void menuMethods(int option) {
		try {
			System.out.println(
					"If you want to read from a file, enter any key | If you want to read from a webpage, enter 'URL'> ");
			String fileType = scan.nextLine();
			ioh.parse(option, fileType);
			endOfProgram();
		} catch (IOException e) {
			System.out.println("File not found.\n \nType in " + option + ", hit Enter and try again> ");
			choices();
		}
	}

	/*
	 * This method allows the user to quit or continue using the application once it
	 * has already run
	 */
	private void endOfProgram() {
		System.out.println("\n***********************************************************************");
		System.out.println("***  Enter 'Menu' to return to the main screen | Enter '4' to quit  ***");
		System.out.println("***********************************************************************");
		choices();
	}

}
