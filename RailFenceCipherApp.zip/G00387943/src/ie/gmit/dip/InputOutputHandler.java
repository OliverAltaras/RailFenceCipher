package ie.gmit.dip;

import java.io.*;
import java.net.URL;
import java.util.Scanner;

//Declaring the variables
public class InputOutputHandler {
	RailFenceCypher rfc = new RailFenceCypher();
	Scanner scan = new Scanner(System.in);
	private String line;
	private BufferedReader br;
	private String enc;

	/*
	 * Manages the files/URLs to be encrypted, decrypted or displayed as a rail
	 * fence
	 */
	public void parse(int option, String fileType) throws IOException {
		// The user has to enter 2 inputs at first: the source of the file or URL and
		// where they want to save it
		System.out.println("Enter the source file/URL> ");
		String sourceFile = scan.next();
		System.out.println("Enter the destination file> ");
		String fileName = scan.next();

		// This piece of code allows the user to choose between reading from a URL or
		// from a text file on the menu
		if (fileType.equals("URL") || fileType.equals("Url") || fileType.equals("url"))
			br = new BufferedReader(new InputStreamReader(new URL(sourceFile).openStream()));
		else
			br = new BufferedReader(new InputStreamReader(new FileInputStream(sourceFile)));

		// Creating a file writer that takes the fileName variable input as argument
		FileWriter text = new FileWriter(fileName);

		// Prompts the user to enter the key and the offset for arguments of the rail
		// fence cipher methods invoked below
		int key = rfc.key();
		int offset = rfc.offset();

		/*
		 * The conditional statements below invoke a cipher method depending on which
		 * argument is passed in the class Menu. The methods are encrypt, decrypt and
		 * displayCypher
		 */
		while ((line = br.readLine()) != null) {
			if (option == 1)
				enc = rfc.encrypt(line, key, offset);
			else if (option == 2)
				enc = rfc.decrypt(line, key, offset);
			else
				enc = rfc.displayCypher(line, key, offset);

			text.write(enc);
			text.write("\n");

		}

		// Once a file is generated, the message below shows the file's name and path
		System.out.println("Your file has been successfully saved as: " + fileName);

		br.close();
		text.close();
	}
}
