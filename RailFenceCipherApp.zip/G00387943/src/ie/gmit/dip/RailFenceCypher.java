//The following link was consulted to help developing this class https://www.youtube.com/watch?v=reKq19WH4q8
//Codes used during the labs at GMIT and posts on the Moodle discussion forums were also used
package ie.gmit.dip;

import java.util.Scanner;

//Variables are declared, as well as an instance of Scanner for user input
public class RailFenceCypher {
	Scanner scan = new Scanner(System.in);
	private char[][] matrix = null;
	private int offset;
	private int key;
	private boolean dir;
	private int row;

	/*
	 * Method allows user to input the key and makes sure the value is a positive
	 * integer. This method is invoked in the InputOutputHandler class
	 */
	public int key() {
		try {
			System.out.println("Enter the key> ");
			this.key = Integer.parseInt(scan.nextLine());
			if (key <= 0) {
				System.out.println("<---Invalid Input. Make sure you enter a positive number--->");
				key();
			}
		} catch (NumberFormatException nfe) {
			System.out.println("<---Invalid Input. Make sure you enter a positive number--->");
			key();
		}

		return key;
	}

	/*
	 * Method allows user to input the offset and makes sure the value is a positive
	 * integer smaller than the key. This method is invoked in the
	 * InputOutputHandler class
	 */
	public int offset() {
		try {
			System.out.println("Enter the offset> ");
			this.offset = Integer.parseInt(scan.nextLine());
			if (offset >= key || offset < 0) {
				System.out.println("<---Invalid Input. The offset value must be positive and smaller than the key--->");
				offset();
			}
		} catch (NumberFormatException nfe) {
			System.out.println("<---Invalid Input. The offset value must be positive and smaller than the key--->");
			offset();
		}

		return offset;
	}

	/*
	 * The following three methods pass three parameters each: A String, which is
	 * the text file or URL chosen by the user, and two ints: one for the key and
	 * one for the offset, both of which are passed by the methods above
	 */
	public String encrypt(String plainText, int key, int offset) {

		// String builder created to append the characters
		StringBuilder sb = new StringBuilder();

		// Initialises the row according to the the chosen offset
		row = offset;
		/*
		 * This piece of code makes sure that the zig-zag moves from top to bottom,
		 * unless the offset is the last row
		 */
		dir = false;
		if (row > 0)
			dir = true;

		/*
		 * The 2D array "matrix" takes the "key" variable as the amount of rows and the
		 * "plainText" variable's length as the amount of columns
		 */
		matrix = new char[key][plainText.length()];

		/*
		 * This loop populates the matrix's columns with the plain text and moves them
		 * to different rows
		 */
		for (int i = 0; i < plainText.length(); i++) {
			matrix[row][i] = plainText.charAt(i);

			// if the row on the matrix is the first or the last one, the direction
			// (up/down) is changed
			if (row == 0 || row == key - 1)
				dir = !dir;

			if (dir)
				row++;
			else
				row--;
		}

		// Writing the matrix line by line, therefore creating the encrypted text
		for (int i = 0; i < key; i++) {
			for (int j = 0; j < plainText.length(); j++) {
				// Only appending if index not empty (blank spaces on the zig-zag)
				if (matrix[i][j] != 0)
					sb.append(matrix[i][j]);
			}

		}
		// using the toString() method to convert the character array into a string
		return sb.toString();
	}

	// Method that decrypts the file/URL
	public String decrypt(String cipherText, int key, int offset) {
		StringBuilder sb = new StringBuilder();
		dir = false;
		int row = offset;
		if (row > 0)
			dir = true;

		/*
		 * Unlike the previous method, this one takes the encrypted text as its columns,
		 * rather than the plain text
		 */
		matrix = new char[key][cipherText.length()];

		/*
		 * This creates a zig-zag of '?', which marks where the encrypted characters
		 * should be placed
		 */
		for (int i = 0; i < cipherText.length(); i++) {
			matrix[row][i] = '?';
			if (row == 0 || row == key - 1)
				dir = !dir;

			if (dir)
				row++;
			else
				row--;
		}

		// Afterwards, the '?' are replaced by the actual characters
		int index = 0;
		dir = false;
		for (int i = 0; i < key; i++) {
			for (int j = 0; j < cipherText.length(); j++) {
				if (matrix[i][j] == '?' && index < cipherText.length()) {
					matrix[i][j] = cipherText.charAt(index++);
				}
			}
		}
		// Finally, the characters are read diagonally and written out,
		// generating the decrypted/plain text
		row = offset;
		if (row > 0)
			dir = true;
		for (int i = 0; i < cipherText.length(); i++) {
			sb.append(matrix[row][i]);

			if (row == 0 || row == key - 1)
				dir = !dir;

			if (dir)
				row++;
			else
				row--;
		}

		return sb.toString();
	}

	// Method to display the cipher's zig-zag
	public String displayCypher(String displayedText, int key, int offset) {

		StringBuilder sb = new StringBuilder();

		row = offset;
		dir = false;
		if (row > 0)
			dir = true;

		/*
		 * In order for the rail fence display to be readable in a zig-zag, a plain text
		 * should be entered as the displayedText variable.
		 */
		matrix = new char[key][displayedText.length()];
		for (int i = 0; i < displayedText.length(); i++) {
			matrix[row][i] = displayedText.charAt(i);
			if (row == 0 || row == key - 1)
				dir = !dir;
			
			if (dir)
				row++;
			else
				row--;
		}

		/*
		 * After each iteration, blank spaces are added to the array, therefore creating
		 * the zig-zag shape
		 */
		for (int i = 0; i < key; i++) {
			for (int j = 0; j < displayedText.length(); j++) {
				sb.append(matrix[i][j] + " ");
			}
			sb.append("\n");

		}

		return sb.toString();
	}

}
